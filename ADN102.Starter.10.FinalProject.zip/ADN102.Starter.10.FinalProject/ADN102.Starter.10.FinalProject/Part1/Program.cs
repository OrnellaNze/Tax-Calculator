﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Final_Project
{
    class Program
    {
        public static void Main()
        {
              //Part1.Program.Main();
              Part2.Program.Main();
            //   Part3.Program.Main();

        }
    }
}
