﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Part2
{


    public class EmployeeRecord
    {
        // create an employee Record with public properties
        //    ID                        a number to identify an employee
        public int Id { get; set; }
        //    Name                      the employee name
        public string Name { get; set; }
        //    StateCode                 the state collecting taxes for this employee
        public string StateCode { get; set; }
        //    HoursWorkedInTheYear      the total number of hours worked in the entire year (including fractions of an hour)
        public decimal HoursWorkedInTheYear { get; set; }
        //    HourlyRate                the rate the employee is paid for each hour worked
        //                                  assume no changes to the rate throughout the year.
        public decimal HourlyRate { get; set; }

        //    provide a constructor that takes a csv and initializes the employeerecord
        //       do all error checking and throw appropriate exceptions

        public EmployeeRecord(string csv)
        {
            var data = csv.Split(",");
            if (data.Length != 5)
            {
                throw new Exception($"I was expecting the length to be five but it was actually {data.Length} the whole line is {csv}");
            }
            Id = int.Parse(data[0]);
            Name = data[1];
            StateCode = data[2];
            decimal temp;
            if (!decimal.TryParse(data[3], out temp))
            {
                throw new Exception($"I was expecting the floor to be a decimal, it was actually {data[3]} the line is {csv}");
            }
            HoursWorkedInTheYear = temp;
            if (!decimal.TryParse(data[4], out temp))
            {
                throw new Exception($"I was expecting the floor to be a decimal, it was actually {data[3]} the line is {csv}");
            }

           
           
            HourlyRate = temp;
        }
        //    provide an additional READ ONLY property called  YearlyPay that will compute the total income for the employee
        //        by multiplying their hours worked by their hourly rate

        public decimal YearlyPay { get { return HoursWorkedInTheYear * HourlyRate; } }

        //    provide an additional READONLY property that will compute the total tax due by:
        //        calling into the taxcalculator providing the statecode and the yearly income computed in the YearlyPay property
        public decimal TaxDue { get { return Part1.TaxCalculator.ComputeTaxFor(StateCode, YearlyPay); } }

        //    provide an override of toString to output the record : including the YearlyPay and the TaxDue
        public override string ToString()
        {
            return $"{Id} {Name,15} {StateCode,15} { HoursWorkedInTheYear,15} {HourlyRate,15} {YearlyPay,15} {TaxDue}";
        }
    }

    public class EmployeesList
    {

        // create an EmployeeList class that will read all the employees from the Employees.csv file
        // the logic is similar to the way the taxcalculator read its taxrecords
       // System.IO.TextReader reader = System.IO.File.OpenText("employees.csv");


        // Create a List of employee records.  The employees are arranged into a LIST not a DICTIONARY
        //   because we are not accessing the employees by state,  we are accessing the employees sequentially as a list
        public static List<EmployeeRecord> employeesRecords = new List<EmployeeRecord>();




        // create a static constructor to load the list from the file
        //   be sure to include try/catch to display messages

        static EmployeesList()
        {
            foreach (string line in System.IO.File.ReadAllLines("employees.csv"))
            {

                try
                {
                    employeesRecords.Add(new EmployeeRecord(line));
                }
                catch (Exception ex)
                {

                }

            }
        }

    }


    class Program
    {

        // loop over all the employees in the EmployeeList and print them
        // If the ToString() in the employee record is correct, all the data will print out.

        public static void Main()
        {

            try
            {
                // write your logic here
                foreach (var z in EmployeesList.employeesRecords)
                {

                    Console.WriteLine(z);
                }
            }

            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
    }
}

