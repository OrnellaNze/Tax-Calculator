﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Part1
{

    public class TaxRecord
    {

        // create a TaxRecord class representing a line from the file.
        // It should have public properties of the correct type
        // for each of the columns in the file
        //  StateCode   (used as the key to the dictionary)
        public string StateCode { get; set; }
        //  State       (Full state name)
        public string State { get; set; }
        //  Floor       (lowest income for this tax bracket)
        public decimal Floor { get; set; }
        //  Ceiling     (highest income for this tax bracket )
        public decimal Ceiling { get; set; }
        //  Rate        (Rate at which income is taxed for this tax bracket)
        public decimal Rate { get; set; }
        //
        //  Create a ctor taking a single string (a csv) and use it to load the properties in the record
        public TaxRecord(string csv)
        {
            var data = csv.Split(",");
            if (data.Length != 5)
            {
                //  Be sure to throw detailed exceptions when the data is invalid
                throw new Exception($"I was expecting the length to be five but it was actually {data.Length} the whole line is {csv} ");
            }
            StateCode = data[0];
            State = data[1];
            decimal temp;
            if (!decimal.TryParse(data[2], out temp))
            {
                throw new Exception($"I was expecting the floor to be a decimal, it was actually {data[2]} the line is {csv}");
            }
            Floor = temp;
            if (!decimal.TryParse(data[3], out temp))
            {
                throw new Exception($"I was expecting the ceiling to be a decimal, it was actually {data[3]} the line is {csv}");
            }
            Ceiling = temp;
            if (!decimal.TryParse(data[4], out temp))
            {
                throw new Exception($"I was expecting the rate to be a decimal, it was actually {data[4]} the line is {csv}");
            }
            Rate = temp;
        }

        //  Create an override of ToString to print out the tax record info nicely
        public override string ToString()
        {
            return $"{StateCode} {State,15} {Floor,15} {Ceiling,15} {Rate}";
        }


    }  // this is the end of the TaxRecord


    static class TaxCalculator
    {
        // Create a static dictionary field that holds a List of TaxRecords and is keyed by a string
        // initialize the static dictionary to a newly create empty one (done in line 69)
        public static Dictionary<string, List<TaxRecord>> TaxRecords = new Dictionary<string, List<TaxRecord>>();

        // create a static constructor that:

        static TaxCalculator()
        {
            // declare a streamreader to read a file
            // read a line from the file
            int counter = 0;
            // open the taxtable.csv file into the streamreader
            foreach (string line in System.IO.File.ReadLines("taxtable.csv"))
            // loop over the lines from the streamreader
            {
                // catch any exceptions while processing each line in another try/catch block located INSIDE the loop
                //   this way if the line in the CSV file is incorrect, you will continue to process the next line
                try
                {
                    // constuct a taxrecord from the (csv) line in the file
                    TaxRecord tax = new TaxRecord(line);
                    List<TaxRecord> temp;
                    // see if the state in the taxrecord is already in the dictionary
                    if (TaxRecords.TryGetValue(tax.StateCode, out temp))
                    //     if it is:  add the new tax record to the list of records in that state
                    {
                        temp.Add(tax);
                    }

                    //     if it is not
                    else
                    {


                        //            create a new list of taxrecords
                        temp = new List<TaxRecord>();
                        //            add the new taxrecord to the list
                        temp.Add(tax);
                        //            add the list to the dictionary under the state for the taxrecord
                        TaxRecords.Add(tax.StateCode, temp);
                    }
                    //provide a way to get out of the loop when you are done with the file....
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }

                System.Console.WriteLine(line);
                counter++;
            }
            Console.WriteLine($"There were {counter} lines.");
           

            // make sure the streamreader is disposed no matter what happens.
        }
        // create a static method (ComputeTaxFor)  to return the computed tax given a state and income
        public static decimal ComputeTaxFor(string stateCode, decimal income)
        {

            //   otherwise use the list to compute the taxes
            //  Create a variable to hold the final computed tax.  set it to 0
            decimal finaltax = 0M;
          
            
            //  
            List<TaxRecord> taxbrackets;
            
            //  use the statecode as a key to find the list of taxrecords for that state
            if (TaxRecords.TryGetValue(stateCode.ToUpper(),out taxbrackets))
            {
                //  loop over the list of taxrecords for the state
                foreach (var tax in taxbrackets)
                {
                    //     check to see if the income is within the tax bracket using the floor and ceiling properties in the taxrecord
                    if (income > tax.Ceiling)
                    {


                        //     if NOT:  (the income is greater than the ceiling)
                        //        compute the total tax for the bracket and add it to the running total of accumulated final taxes
                        decimal totaltax = (tax.Ceiling - tax.Floor) * tax.Rate;
                        //        the total tax for the bracket is the ceiling minus the floor times the tax rate for that bracket.  
                        //        all this information is located in the taxrecord
                        //        after adding the total tax for this bracket, continue to the next iteration of the loop
                        finaltax += totaltax;
                    }
                    //  IF The income is within the tax bracket(the income is higher than the floor and lower than the ceiling
                    if (income > tax.Floor && income < tax.Ceiling)
                    {


                        //        compute the final tax by adding the tax for this bracket to the accumulated taxes
                        decimal totaltax = (income - tax.Floor) * tax.Rate;
                        //        the tax for this bracket is the income minus the floor time the tax rate for this bracket
                        //        this number is the total final tax, and can be returned as the final answer
                        return finaltax + totaltax;
                    }
                }
            }

            //   throw an exception if the state is not found.
            else
            {
                throw new Exception($"I could not find the taxbracket for {stateCode}");
            }
              
            return finaltax;

        }
        // try to figure out how to implement the Verbose option AFTER you have everything else done.

    
    }  // this is the end of the Tax Calculator




    public class Program
    {
        public static void Main()
        {
            // create an infinite loop to:
            // prompt the user for a state and an income
            // validate the data
            // calculate the tax due and print out the total
            // loop

            // after accomplishing this, you may want to also prompt for verbose mode or not in this loop
            // wrap everythign in a try/catch INSIDE the loop.  print out any exceptions that are unhandled
            //  something like this:


            do
            {
                try
                {
                    var x = TaxCalculator.TaxRecords;
                    // put your logic here
                    //string Line;
                    //Line = Console.ReadLine();
                    //TaxRecord R = new TaxRecord(Line);
                    //Console.WriteLine(R);
                    Console.WriteLine("Enter a state");
                    string state = Console.ReadLine();
                    Console.WriteLine("Enter an income");
                    string incomeString = Console.ReadLine();
                    decimal income = decimal.Parse(incomeString);
                    decimal tax = TaxCalculator.ComputeTaxFor(state, income);
                   Console.WriteLine(tax);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            } while (true);


        }
    }

}